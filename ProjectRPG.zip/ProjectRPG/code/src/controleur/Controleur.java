package controleur;

import modele.Affichable;
import modele.Afficher;
import modele.Items;
import modele.Objets;
import modele.classePersonnage.ClasseFactory;
import modele.classePersonnage.FactoryFuturiste;
import modele.classePersonnage.FactoryMedievale;
import modele.entite.Ennemi;
import modele.entite.Joueur;
import modele.prototype.PrototypeEnnemi;
import modele.prototype.PrototypeJoueur;
import modele.prototype.PrototypeSalle;
import modele.salle.concrete.SalleGlobale;
import modele.salle.factory.*;
import vue.Ihm;

import java.util.*;

public class Controleur{

    private final Ihm ihm;
    private ClasseFactory classeFactory;
    private SalleFactory salleFactory;
    private int indice = 0;
    private SalleGlobale[] monde;
    private int nbSalles;
    private ArrayList<Items> items_magasin;
    private Joueur j;
    public static final String ANSI_RED = "\u001B[31m";
    public Controleur(Ihm ihm) {
        this.ihm = ihm;
    }
    private final Random random = new Random();
    private int nombreRespawnPre = 0;

    public void jouer() {

        String choix_theme = ihm.choix_theme();
        switch (choix_theme) {
            case "M":
                classeFactory = new FactoryMedievale();
                salleFactory = new SalleMedievaleFactory();
                break;
            case "F":
                classeFactory = new FactoryFuturiste();
                salleFactory = new SalleFuturisteFactory();
                break;
        }

        String classe = ihm.classe_joueur(choix_theme);
        String nom_joueur = ihm.choix_nom();
        creation_joueur(nom_joueur,classe);
        nbSalles = ihm.choix_taille_donjon();
        ihm.debut_partie();
        ihm.pause(3);

        creerMonde(nbSalles);
        items_magasin = salleFactory.shop();

        String cj;
        do {
            cj = ihm.getMenuJoueur(j);
        } while (!cj.equals("D"));
        Map<Integer, PrototypeSalle> prototypeSalleMap = new HashMap<>();
        Map<Integer, PrototypeJoueur> prototypeJoueurMap = new HashMap<>();
        Map<Integer, Map<Ennemi, PrototypeEnnemi>> prototypeEnnemiMap = new HashMap<>();

        while (true) {

            if (!prototypeSalleMap.containsKey(indice)) {
                prototypeSalleMap.put(indice, monde[indice].creerPrototypeSalle().copier());
                prototypeJoueurMap.put(indice, j.creerPrototypeJoueur().copier());
                prototypeEnnemiMap.put(indice, creerPrototypeDesEnnemis());
            }
            if (monde[indice].sortie() && !monde[indice].isPremier_spawn() && monde[indice].aucunEnnemi()) {
                indice++;
                if (indice < nbSalles){
                    monde[indice].setPremier_spawn(true);
                }
            }
            else if (monde[indice].sortie() && !monde[indice].isPremier_spawn() && !monde[indice].aucunEnnemi()){
                System.out.println(ANSI_RED+"Vous devez avoir vaincu tous les ennemis pour accéder à la salle suivant !"+monde[indice].getCouleur());
                monde[indice].setPremier_spawn(true);
            }
            else if(monde[indice].entree() && !monde[indice].isPremier_spawn() && indice != 0){
                indice--;
                monde[indice].setPremier_spawn(true);
            }
            else {
                monde[indice].setPremier_spawn(false);
                ihm.num_salle(indice);
                (monde[indice]).affichageSalle();
                int dep = ihm.deplacement();
                if (dep == -1){
                    int v = ihm.afficher_externe(j);
                    if(v == 4){
                        magasin();
                    }
                    else {
                        while (v != -3) {
                            if (!(v < 0)) {
                                consommer(v, j);
                            }
                            v = ihm.afficher_interne(j);
                        }
                        monde[indice].setPremier_spawn(true);
                    }
                }
                if(monde[indice].verif_deplacement(dep,indice)){
                    monde[indice].deplacement(dep,indice);
                    if(!monde[indice].sur_objet()){
                        if(monde[indice].sur_ennemis()){
                            boolean resCombat = phaseDeCombat(j,monde[indice]);
                            if (resCombat) {
                                System.out.println("Combat Gagné");
                                ihm.pause(2);
                            } else {
                                    String choix = ihm.choix_fin_partie();
                                    if (choix.equals("R") && nombreRespawnPre < 2) {
                                        nombreRespawnPre++;
                                        revenirSallePrecedente(j,prototypeSalleMap, prototypeJoueurMap, prototypeEnnemiMap);
                                    }
                                    else if(choix.equals("R") && nombreRespawnPre > 2){
                                        ihm.condamner();
                                        nombreRespawnPre = 0;
                                        recommencerDonjon(j,prototypeSalleMap,prototypeJoueurMap, prototypeEnnemiMap);
                                    }
                                    else if(choix.equals("S")){
                                        nombreRespawnPre = 0;
                                        recommencerDonjon(j,prototypeSalleMap,prototypeJoueurMap, prototypeEnnemiMap);
                                    }
                            }
                        }
                    }
                }
            }
            if (indice == nbSalles) {
                System.out.println("Fin du jeu"+"\n"+"Félicitations à vous !");
                break;
            }
        }
    }

    private Map<Ennemi, PrototypeEnnemi> creerPrototypeDesEnnemis() {
        Map<Ennemi, PrototypeEnnemi> prototypeEnnemisTemp = new HashMap<>();
        for (String nomEnnemi : monde[indice].getEnnemisSurMap().keySet()) {
            Ennemi ennemi = monde[indice].getEnnemisSurMap().get(nomEnnemi);
            PrototypeEnnemi prototypeEnnemi = ennemi.creerPrototypeEnnemi().copier();
            prototypeEnnemisTemp.put(ennemi, prototypeEnnemi);
        }
        return prototypeEnnemisTemp;
    }


    private void restaurerPrototypeDesEnnemis(Map<Integer, Map<Ennemi, PrototypeEnnemi>> lePrototypeDesEnnemis) {
        if (lePrototypeDesEnnemis.containsKey(indice)) {
            Map<Ennemi, PrototypeEnnemi> prototypeEnnemisSalle = lePrototypeDesEnnemis.get(indice);
            for (Ennemi ennemi : prototypeEnnemisSalle.keySet()) {
                PrototypeEnnemi prototypeEnnemi = prototypeEnnemisSalle.get(ennemi).copier();
                ennemi.restaurerPrototypeEnnemi(prototypeEnnemi);
            }
        }
    }


    public void revenirSallePrecedente(Joueur j, Map<Integer, PrototypeSalle> lesPrototypeSalle, Map<Integer, PrototypeJoueur> lePrototypeJoueur, Map<Integer, Map<Ennemi, PrototypeEnnemi>> lePrototypeEnnemis) {
        monde[indice].restaurerPrototypeSalle(lesPrototypeSalle.get(indice).copier());
        restaurerPrototypeDesEnnemis(lePrototypeEnnemis);
        if (indice != 0) {
            indice--;
            monde[indice].setPremier_spawn(true);
        }
        for(int h = 0; h<monde[indice].getHauteur(); h++){
            for(int i = 0; i<monde[indice].getLargeur(); i++){
                if(!(monde[indice].getCarte()[h][i].equals(lesPrototypeSalle.get(indice).getCarte()[h][i]))){
                    lesPrototypeSalle.get(indice).carte[h][i] = new Afficher(" ");
                }
            }
        }
        monde[indice].setCarte(lesPrototypeSalle.get(indice).getCarte());
        monde[indice].setPosition_joueurMort_x(); monde[indice].setPosition_joueurMort_y();
        j.restaurerPrototypeJoueur(lePrototypeJoueur.get(indice).copier());
        monde[indice].carte[monde[indice].getHauteur()-1][monde[indice].getLargeur()/2] = j;
        monde[indice].carte[0][monde[indice].getLargeur()/2] = new Afficher("S");
    }

    public void recommencerDonjon(Joueur j, Map<Integer, PrototypeSalle> lesPrototypeSalle, Map<Integer, PrototypeJoueur> lePrototypeJoueur, Map<Integer, Map<Ennemi, PrototypeEnnemi>> lePrototypeEnnemis) {
        while(indice >= 0){
            monde[indice].restaurerPrototypeSalle(lesPrototypeSalle.get(indice).copier());
            restaurerPrototypeDesEnnemis(lePrototypeEnnemis);
            monde[indice].setCarte(lesPrototypeSalle.get(indice).getCarte());
            monde[indice].remplacerJoueur(j);
            monde[indice].setPremier_spawn(true);
            monde[indice].setPosition_joueurMort_x();
            monde[indice].setPosition_joueurMort_y();
            indice--;
        }
        indice = 0;
        j.restaurerPrototypeJoueur(lePrototypeJoueur.get(0).copier());
        j.setVie(1.0);
        j.retirerConsommable();
    }

    public boolean phaseDeCombat(Joueur j1, SalleGlobale sallePos) {
        boolean tropFaible = false;
        String couleur = sallePos.getCouleur();
        String posMonstre = "" + sallePos.getPositionX() + "" + sallePos.getPositionY();
        String actionDuPersonnage;
        for (String p : sallePos.getEnnemisSurMap().keySet()) {
            if (p.equals(posMonstre)) {
                System.out.println("LE COMBAT COMMENCE !");
                Ennemi ennemi = sallePos.getEnnemisSurMap().get(p);
                System.out.println(ennemi.getNom() + " possède " + ennemi.getVie()+"HP et " + ennemi.getDegat() + "DMG\n");
                while(j1.getVie() > 0 && ennemi.getVie() > 0) {
                    do {
                        actionDuPersonnage = ihm.actionPersonnage();
                        if (actionDuPersonnage.equals("Attaquer") || actionDuPersonnage.equals("Pouvoir")) {
                            if (actionDuPersonnage.equals("Pouvoir")) {
                                j1.superPouvoir();
                            }
                            int resultatPrecision = random.nextInt(101);
                            if (resultatPrecision <= j1.getPourcentageDext()) {
                                ennemi.setDegatSubis(j1.getPtsAttaque());
                                System.out.println(couleur + "Vous " + j1.getNomAttaque() + " et vous lui affligez " + String.format("%.2f", j1.getPtsAttaque()) + " degats");
                                ihm.pause(1);
                                if (ennemi.getVie() <= 0.0) {
                                    System.out.println(couleur + "\nVous avez vaincu votre ennemis !");
                                    sallePos.ennemis_sur_map.remove(p);
                                    return true;
                                }
                                System.out.println(ANSI_RED + "Votre ennemi possède encore " + String.format("%.2f", ennemi.getVie()) + "HP\n");
                                ihm.pause(1);
                            } else {
                                System.out.println(couleur+"Vous loupez votre attaque");
                            }
                        } else if (actionDuPersonnage.equals("Consommer")) {
                            int itemAConso = ihm.choixInventaire(j1);
                            if (itemAConso >= -1) {
                                if (itemAConso >= 0)
                                    consommer(itemAConso,j);
                            } else {
                                actionDuPersonnage = "";
                            }
                        }
                        System.out.println(ANSI_RED + ennemi.getNom() + " " + ennemi.getNomAttaque());
                        ihm.pause(1);
                        if (ennemi.getDegat() < j1.getPtsDefense()) {
                            tropFaible = true;
                        }
                        if (actionDuPersonnage.equals("Esquiver")) {
                            if (!tropFaible) {
                                System.out.println(couleur + "Vous tentez d'esquiver . . .");
                                ihm.pause(1);
                                int resultatEsquive = random.nextInt(101);
                                if (resultatEsquive <= j1.getPourcentageEsquive()) {
                                    System.out.println(couleur + "Le joueur a esquivé l'attaque !");
                                } else {
                                    j1.setDegatSubis(ennemi.getDegat() - j1.getPtsDefense());
                                    System.out.println(couleur + "Le joueur n'a pas esquivé et prend " + String.format("%.2f", (ennemi.getDegat() - j1.getPtsDefense())) + " points de dégâts.");
                                }
                            } else {
                                System.out.println(couleur + "Esquive inutile l'ennemi est trop faible");
                            }
                        } else {
                            if (tropFaible) {
                                System.out.println(couleur + "L'ennemi est trop faible pour vous infliger des dégâts");
                            } else {
                                j1.setDegatSubis(ennemi.getDegat() - j1.getPtsDefense());
                                System.out.println(couleur + "Le joueur prend " + String.format("%.2f", (ennemi.getDegat() - j1.getPtsDefense())) + " points de dégâts.");
                            }
                        }
                    } while (actionDuPersonnage.equals(""));
                    ihm.pause(1);
                    if (j1.getVie() <= 0.0) {
                        System.out.println(ANSI_RED + "\nGAME OVER !");
                        return false;
                    } else {
                        System.out.println(couleur + "Il vous reste " + String.format("%.2f", j1.getVie()) + " HP\n");
                    }
                }
            }
        }
        return true;
    }


    public void magasin(){ //Possibilité de faire evoluer ce magasin en ajoutant differents objets supplémentaires
        System.out.println("Bienvenue dans le Magasin !" +"\n");
        int choix = ihm.choixMagasin(j,items_magasin);
        if (choix == -1){
            return;
        }
        Items tmp = items_magasin.get(choix);
        switch (tmp.getType()){
            case "Token":
                items_magasin.remove(choix);
                j.setNbSuperPouvoir(j.getNbSuperPouvoir()+1);
                j.payer(tmp.getPrix());
                System.out.println("Vous avez payer "+tmp.getPrix()+" pieces et vous avez gagnez 1 points de Super Pouvoir");
        }
    }

    public void consommer(int indice, Joueur j){
        Objets o = j.getInventaire().get(indice);
        switch (o.getType()) {
            case "Potion" :
                j.setVie(j.getVie() + o.getValeur());
                System.out.println("Vous gagnez " + o.getValeur() + " points de vie\n");
                j.getInventaire().remove(o);
                break;
            case "Arme" :
                Objets armeActuelle = j.getEquipements().get("Arme");
                j.getEquipements().put("Arme",o);
                j.getInventaire().add(armeActuelle);
                j.getInventaire().remove(o);
                System.out.println("Vous avez équipé "+o.getIntitule()+"\n");
                break;
            case "Token":
                j.setNbSuperPouvoir(j.getNbSuperPouvoir()+1);
                j.getInventaire().remove(o);
                break;
        }
    }


    public void creerMonde(int nbSalles) {
        monde = new SalleGlobale[nbSalles];
        for (int i = 0; i < monde.length; i++) {
            monde[i] = salleFactory.creerSalle(j);
            monde[i].creerSalleGlobale();
            monde[i].setIndice_salle(i);
            if (i == monde.length-1){
                monde[i].ajoutBoss();
            }
            else {
                monde[i].ajoutEnnemis();
                monde[i].ajoutObjets();
            }
        }
    }


    public void creation_joueur(String nom, String classe){
        if (classe.equals("CHEVALIER") || classe.equals("CYBORG")){
            j = classeFactory.creer_melee(nom);
        }
        else if (classe.equals("FANTASSIN") || classe.equals("SPECTRE")){
            j = classeFactory.creer_distance(nom);
        }
        else if(classe.equals("HACKER") || classe.equals("MAGE")){
            j = classeFactory.creer_healer(nom);
        }
    }
}
