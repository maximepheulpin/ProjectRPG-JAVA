package modele.prototype;

import modele.Objets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PrototypeJoueur {
    private ArrayList<Objets> inventaire;
    private Map<String, Objets> equipements;
    private int pieces;
    private double vie;

    public PrototypeJoueur(ArrayList<Objets> inventaire, Map<String, Objets> equipements, int pieces, double vie) {
        this.inventaire = inventaire;
        this.equipements = equipements;
        this.pieces = pieces;
        this.vie = vie;
    }

    public PrototypeJoueur copier(){
        return new PrototypeJoueur(new ArrayList<>(this.inventaire), new HashMap<>(this.equipements), this.pieces, this.vie);
    }

    public ArrayList<Objets> getInventaire() {
        return inventaire;
    }

    public Map<String, Objets> getEquipements() {
        return equipements;
    }

    public int getPieces() {
        return pieces;
    }

    public double getVie() {
        return vie;
    }
}
