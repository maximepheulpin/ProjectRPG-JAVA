package modele.prototype;

import modele.Affichable;
import modele.Objets;
import modele.entite.Ennemi;
import modele.entite.Joueur;

import java.util.HashMap;
import java.util.Map;

public class PrototypeSalle implements Affichable {

    Joueur j1;
    public Affichable[][] carte;
    public int hauteur, largeur;
    private int position_joueur_x;
    private int position_joueur_y;
    public boolean premier_spawn = true;
    public Map<String, Objets> objets_sur_map; //XY, Objets

    public Map<String, Ennemi> ennemis_sur_map; //XY, Ennemis
    public boolean entree = false;
    private String debut = "E";
    private String caractere = "X";

    public PrototypeSalle(Joueur j1, Affichable[][] carte, int hauteur, int largeur, int position_joueur_x, int position_joueur_y, boolean premier_spawn, Map<String, Objets> objets_sur_map, Map<String, Ennemi> ennemis_sur_map, boolean entree, String debut, String caractere) {
        this.j1 = j1;
        this.carte = carte;
        this.hauteur = hauteur;
        this.largeur = largeur;
        this.position_joueur_x = position_joueur_x;
        this.position_joueur_y = position_joueur_y;
        this.premier_spawn = premier_spawn;
        this.objets_sur_map = objets_sur_map;
        this.ennemis_sur_map = ennemis_sur_map;
        this.entree = entree;
        this.debut = debut;
        this.caractere = caractere;
    }


    public Joueur getJ1() {
        return j1;
    }

    public Affichable[][] getCarte() {
        return carte;
    }

    public int getHauteur() {
        return hauteur;
    }

    public int getLargeur() {
        return largeur;
    }

    public int getPosition_joueur_x() {
        return position_joueur_x;
    }

    public int getPosition_joueur_y() {
        return position_joueur_y;
    }

    public boolean isPremier_spawn() {
        return premier_spawn;
    }

    public Map<String, Objets> getObjets_sur_map() {
        return objets_sur_map;
    }

    public Map<String, Ennemi> getEnnemis_sur_map() {
        return ennemis_sur_map;
    }

    public boolean isEntree() {
        return entree;
    }

    public String getDebut() {
        return debut;
    }

    @Override
    public String getCaractere() {
        return caractere;
    }
    public PrototypeSalle copier() {
        PrototypeSalle copie = new PrototypeSalle(
                this.j1,
                new Affichable[this.hauteur][this.largeur],
                this.hauteur,
                this.largeur,
                this.position_joueur_x,
                this.position_joueur_y,
                this.premier_spawn,
                new HashMap<>(this.objets_sur_map),
                new HashMap<>(this.ennemis_sur_map),
                this.entree,
                this.debut,
                this.caractere
        );

        for (int i = 0; i < this.hauteur; i++) {
            for (int j = 0; j < this.largeur; j++) {
                copie.carte[i][j] = this.carte[i][j];
            }
        }

        return copie;
    }

}
