package modele.prototype;

public class PrototypeEnnemi {

    private double degat;
    private double vie;


    public PrototypeEnnemi(double v, double d){
        this.degat = d;
        this.vie = v;
    }

    public PrototypeEnnemi copier(){
        return new PrototypeEnnemi(this.vie,this.degat);
    }

    public double getDegat(){
        return degat;
    }

    public double getVie() {
        return vie;
    }
}