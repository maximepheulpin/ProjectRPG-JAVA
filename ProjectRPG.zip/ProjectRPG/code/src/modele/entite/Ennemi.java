package modele.entite;

import modele.Affichable;
import modele.prototype.PrototypeEnnemi;

public class Ennemi extends Entite implements Affichable {

    private double degat;


    public Ennemi(String nom, String caractere, double force, double dexterite, double constitution, double intelligence, double vitesse, String attaque, double vie, double degat){
        super(force,dexterite,constitution,intelligence,vitesse,nom,vie,caractere,attaque);
        this.degat = degat;
    }

    public PrototypeEnnemi creerPrototypeEnnemi() { //Création d'une sauvegarde (à appeler avant chaque combat)
        return new PrototypeEnnemi(getVie(),degat);
    }

    public void restaurerPrototypeEnnemi(PrototypeEnnemi memento) {
        this.degat = memento.getDegat();
        setVie(memento.getVie());
    }

    public double getDegat(){
        return degat;
    }

    public void setDegat(double degat) {
        this.degat = degat;
    }

}