package modele.entite;

import modele.Affichable;

public abstract class Entite implements Affichable {
    private double force; //quantifie la force physique du personnage : dégâts infligés, charge physique qu'on peut porter…
    private double dexterite; //détermine l'habileté au combat, et la probabilité d'échapper aux pièges.
    private double  constitution; //influe sur la capacité à récupérer les points de vie avec le temps, ainsi que sur le maximum de points de vie.
    private double intelligence; //mesure la capacité à manipuler la magie/outils.
    private double vitesse;
    private String nom;
    private double vie;
    private String attaque;
    private String caractere;


    public Entite(double force, double dexterite, double constitution, double intelligence, double vitesse, String nom, double vie, String caractere, String attaque) {
        this.force = force;
        this.dexterite = dexterite;
        this.constitution = constitution;
        this.intelligence = intelligence;
        this.vitesse = vitesse;
        this.nom = nom;
        this.vie = vie;
        this.caractere = caractere;
        this.attaque = attaque;
    }

    public double getForce() {
        return force;
    }

    public double getDexterite() {
        return dexterite;
    }

    public double getConstitution() {
        return constitution;
    }

    public double getIntelligence() {
        return intelligence;
    }

    public double getVitesse() {
        return vitesse;
    }

    public void setDexterite(double dexterite) {
        this.dexterite = dexterite;
    }

    public String getNom(){return nom;}
    public String getNomAttaque() {
        return attaque;
    }

    public double getVie() {
        return vie;
    }
    public void setDegatSubis(double degatSubis) {
        this.vie -= degatSubis;
    }

    public void setVie(double vie){
        this.vie = vie;
    }

    public void setIntelligence(double intelligence) {
        this.intelligence = intelligence;
    }

    @Override
    public String getCaractere() {
        return caractere;
    }

    public void setForce(double force) {
        this.force = force;
    }
}
