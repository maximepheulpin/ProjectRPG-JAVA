package modele.entite;

import modele.prototype.PrototypeJoueur;
import modele.Objets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class Joueur extends Entite{

    private ArrayList<Objets> inventaire;
    private Map<String, Objets> equipements;
    private int pieces;

    public Joueur(String nom,String caractere,double force, double dexterite, double constitution, double intelligence, double vitesse, Objets arme, Objets tete, Objets haut, Objets bas, Objets pieds, String a, int p, int vie) {
        super(force, dexterite, constitution, intelligence, vitesse, nom, vie, caractere, a);
        equipements = new HashMap<>();
        equipements.put(arme.getType(),arme);
        equipements.put(tete.getType(),tete);
        equipements.put(haut.getType(),haut);
        equipements.put(bas.getType(), bas);
        equipements.put(pieds.getType(), pieds);
        this.inventaire = new ArrayList<>();
        this.pieces = p;
    }

    public PrototypeJoueur creerPrototypeJoueur() { //Création d'une sauvegarde (à appeler avant chaque combat)
        return new PrototypeJoueur(inventaire, equipements, pieces, getVie());
    }

    public void restaurerPrototypeJoueur(PrototypeJoueur memento) {
        this.inventaire = memento.getInventaire();
        this.equipements = memento.getEquipements();
        this.pieces = memento.getPieces();
        setVie(memento.getVie());
    }

    public void afficherInventaire() {
        String header = "╔═════════════════════════ INVENTAIRE ═════════════════════════╗";
        int longueurTotale = header.length();
        int cpt = 1;
        System.out.println(header);
        if (!inventaire.isEmpty()) {
            for (Objets ob : inventaire) {
                afficherLigneCentree((cpt++)+" "+ob.getType() + " : " + ob.getIntitule() + " || Statistiques : " + ob.getValeur(), longueurTotale);
            }
        } else {
            afficherLigneCentree("Vous n'avez pas d'objets",longueurTotale);
        }
        afficherLigneCentree("Nombre de pièces : " + pieces, longueurTotale);
        afficherLigneCentree("Votre vie : " + String.format("%.2f",getVie()), longueurTotale);
        afficherLigneCentree("Votre nom : " + getNom(), longueurTotale);
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
    }


    public abstract void superPouvoir();

    public void afficherEquipement() {
        String header = "╔══════════════════════ EQUIPEMENTS ══════════════════════╗";
        int longueurTotale = header.length();
        System.out.println(header);
        for (String k : equipements.keySet()) {
            Objets ob = equipements.get(k);
            afficherLigneCentree(ob.getType() + " : " + ob.getIntitule() + " || Statistiques : " + ob.getValeur(),longueurTotale);
        }
        System.out.println("╚═════════════════════════════════════════════════════════╝");
    }

    public void afficherLigneCentree(String ligne, int longueurTotale) {
        int sideGauche = (longueurTotale - ligne.length()) / 2 - 1;
        int sideDroite = longueurTotale - ligne.length() - sideGauche - 2;
        //System.out.println(sideDroite + " " + sideGauche);
        String ligneCentree = "║";
        for (int i = 0; i < sideGauche; i++) {
            ligneCentree += " ";
        }
        ligneCentree += ligne;
        for (int i = 0; i < sideDroite; i++) {
            ligneCentree += " ";
        }
        ligneCentree += "║";
        System.out.println(ligneCentree);
    }

    public ArrayList<Objets> getInventaire() {
        return inventaire;
    }

    public Map<String, Objets> getEquipements() {
        return equipements;
    }


    //Attaque = Pts Arme x (force + dextérité) / 1 x (2 x 5)
    //Exemple chevalier : 4 x (7 + 4) / 10 = 4.4
    //Exemple fantassin : 7 x (5 + 4) / 10 = 6.3
    //Exemple spectre : 7 x (8 + 3.5) / 10 = 8.05

    //Défense = Pts (Tete+Haut+Bas+) x constitution / 3 x (1 x 5)
    //Exemple chevalier : (5 + 6 + 4) x 6 / 15 = 6
    //Exemple fantassin : (4 + 3 + 6) x 4 / 15 = 3.47
    //Exemple spectre : (3 + 3 + 2) x 2.5 / 15 = 1.3

    //Esquive = Pts Pied x (intelligence + vitesse) / 1 x (2 x 5) x 15
    //Exemple chevalier : 3 x (3.5 + 4.5) / 150 = 0.16 //16% de chance d'esquive
    //Exemple fantassin : 4 x (5 + 6) / 150 = 0.29 //29% de chance d'esquive
    //Exemple spectre : 6 x (4 + 7) / 150 = 0.44 //44% de chance d'esquive
    public double getPtsAttaque() {
        return equipements.get("Arme").getValeur() * ((getForce()) / 5);
    }

    public double getPtsDefense() {
        return (equipements.get("Tete").getValeur() + equipements.get("Haut").getValeur() + equipements.get("Bas").getValeur()) * getConstitution() / 20;
    }

    public double getPourcentageDext() {
        System.out.println((getDexterite() + getForce() + getIntelligence())*4.5);
        return (getDexterite() + getForce() + getIntelligence())*4.5;
    }

    public double getPourcentageEsquive() {
        return equipements.get("Pieds").getValeur() * (getIntelligence() + getVitesse()) / 1.5;
    }

    public void setPieces(int pieces) {
        this.pieces += pieces;
    }

    public void payer(int prix){this.pieces -= prix;}


    public void setInventaire(Objets o, int indice) {
        if (indice == -1){
            inventaire.add(o);
        }
        else{
            inventaire.set(indice-1,o);
        }
    }

    public abstract void setNbSuperPouvoir(int nbSuperPouvoir);

    public abstract int getNbSuperPouvoir();

    public int getPieces() {
        return pieces;
    }

    public int getTaille_inventaire() {
        return inventaire.size();
    }

    public void retirerConsommable() {
        ArrayList<Integer> listCons = new ArrayList<>();
        int cpt = 0;
        for (Objets cons : inventaire) {
            if ("Potion".equals(cons.getType())) {
                listCons.add(cpt);
            }
            cpt++;
        }
        for (int i = 0; i < listCons.size() ; i++) {
            inventaire.remove(listCons.get(i));
        }
    }



}
