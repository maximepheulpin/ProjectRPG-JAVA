package modele;

public interface Affichable {
    String getCaractere();

}
