package modele;

public class Objets implements Affichable{
    private String intitule;
    private double valeur;
    private String type;
    private String caractere;

    public Objets(String t,String i, int v, String c){
        this.intitule = i;
        this.valeur = v;
        this.type = t;
        this.caractere = c;
    }

    public String getCaractere() {
        return caractere;
    }
    public String getIntitule() {
        return intitule;
    }
    public double getValeur() {
        return valeur;
    }
    public String getType() {
        return type;
    }

    public String toString() {
        return intitule + " : " + valeur + '\n';
    }

    public void setValeur(double valeur) {
        this.valeur = valeur;
    }
}
