package modele;

public class Items extends Objets{

    private int prix;
    public Items(String t, String i, int v, String c, int p) {
        super(t, i, v, c);
        this.prix = p;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    @Override
    public String toString() {
        return getIntitule() + " : " + getValeur() + " prix = " + prix;
    }
}
