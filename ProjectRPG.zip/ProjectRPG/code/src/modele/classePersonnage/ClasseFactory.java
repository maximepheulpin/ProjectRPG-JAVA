package modele.classePersonnage;
import modele.entite.Joueur;
import modele.salle.concrete.SalleGlobale;

public interface ClasseFactory {

    Melee creer_melee(String nom);
    Distance creer_distance(String nom);
    Healer creer_healer(String nom);

}
