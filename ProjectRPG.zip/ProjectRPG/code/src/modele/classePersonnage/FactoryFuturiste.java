package modele.classePersonnage;
import modele.Objets;

public class FactoryFuturiste implements ClasseFactory{
    @Override
    public Melee creer_melee(String nom) {
        return new Cyborg(nom,"@", 6.0, 2.0, 7.0, 4.0, 6.0, new Objets("Arme", "Main bionique", 7,"A"), new Objets("Tete", "Metal", 4,"T"), new Objets("Haut", "Metal", 6,"H"), new Objets("Bas", "Metal", 5,"B"), new Objets("Pieds", "Metal", 3,"P"), "tirez sur votre ennemi",0,25);
    }

    @Override
    public Distance creer_distance(String nom) {
        return new Spectre(nom,"@",8.0, 3.5, 2.5, 4.0, 7.0, new Objets("Arme", "Lame d'Éther", 7,"A"), new Objets("Tete", "Balaclava", 3,"T"), new Objets("Haut", "Cape de Camouflage", 3,"H"), new Objets("Bas", "Pantalon", 2,"B"), new Objets("Pieds", "Exo-Propulseurs", 5,"P"), "assassinez votre ennemi",0,25);
    }

    @Override
    public Healer creer_healer(String nom) {
        return new Hacker(nom, "@", 4.5, 4.5, 3.5, 7.0, 5.5, new Objets("Arme", "Puce Neuralink", 7, "A"), new Objets("Tete", "Casque VR", 3, "T"), new Objets("Haut", "T-Shirt", 4, "H"), new Objets("Bas", "Jean", 5, "B"), new Objets("Pieds", "Chaussure", 2, "P"), "H@CK3D", 0, 25);
    }
}
