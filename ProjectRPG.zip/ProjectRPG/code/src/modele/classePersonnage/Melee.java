package modele.classePersonnage;

import modele.Objets;
import modele.entite.Joueur;

public class Melee extends Joueur{
    private int nbSuperPouvoir;
    public Melee(String nom, String caractere, double force, double dexterite, double constitution, double intelligence, double vitesse, Objets arme, Objets tete, Objets haut, Objets bas, Objets pieds, String a, int p, int vie) {
        super(nom, caractere, force, dexterite, constitution, intelligence, vitesse, arme, tete, haut, bas, pieds, a, p, vie);
        this.nbSuperPouvoir = 1;
    }

    public void setNbSuperPouvoir(int nbSuperPouvoir) {
        this.nbSuperPouvoir = nbSuperPouvoir;
    }

    public int getNbSuperPouvoir() {
        return nbSuperPouvoir;
    }

    @Override
    public void superPouvoir() {
        if (this.nbSuperPouvoir > 0) {
            System.out.println("Vous activez votre mode berserk");
            this.setForce(this.getForce() * 2);
            this.setDegatSubis(this.getVie() / 2);
            this.setDexterite(this.getDexterite() / 5);
            this.setIntelligence(0);
            this.nbSuperPouvoir -= 1;
        } else {
            System.out.println("Vous n'avez plus de super pouvoir.");
        }
    }
    public void augmenterRessourceSuperPouvoir(int qte) {
        this.nbSuperPouvoir += qte;
    }
}
