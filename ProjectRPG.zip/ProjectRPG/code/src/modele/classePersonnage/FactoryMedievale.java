package modele.classePersonnage;

import modele.Objets;

public class FactoryMedievale implements ClasseFactory{
    @Override
    public Melee creer_melee(String nom) {
        return new Chevalier(nom, "@", 7.0, 4.0, 6.0, 3.5, 4.5, new Objets("Arme", "Épée", 4,"A"), new Objets("Tete", "Casque", 3,"T"), new Objets("Haut", "Armure", 5,"H"), new Objets("Bas", "Jambières", 4,"B"), new Objets("Pieds", "Bottes", 3,"P"), "donnez un coup",0,25);
    }

    @Override
    public Distance creer_distance(String nom) {
        return new Fantassin(nom,"@", 5.0, 5.0, 4.0, 5.0, 6.0, new Objets("Arme", "Arc", 7,"A"), new Objets("Tete", "Visière", 4,"T"), new Objets("Haut", "Cotte de maille", 3,"H"), new Objets("Bas", "Maillage", 6,"B"), new Objets("Pieds", "Bottes", 4,"P"), "tirez sur votre ennemi",0,20);
    }

    @Override
    public Healer creer_healer(String nom) {
        return new Mage(nom, "@", 5.0, 4.5, 3.0, 8.5, 5.5, new Objets("Arme", "Bâton magique", 5,"A"), new Objets("Tete", "Chapeau", 3,"T"), new Objets("Haut", "Cape", 4,"H"), new Objets("Bas", "Pantalon", 2,"B"), new Objets("Pieds", "Chaussures", 1,"P"), "envoyez un sort",0,25);
    }
}
