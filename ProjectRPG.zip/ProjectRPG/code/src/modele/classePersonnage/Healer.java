package modele.classePersonnage;

import modele.Objets;
import modele.entite.Joueur;

public class Healer extends Joueur {

    private int nbSuperPouvoir;
    public Healer(String nom, String caractere, double force, double dexterite, double constitution, double intelligence, double vitesse, Objets arme, Objets tete, Objets haut, Objets bas, Objets pieds, String a, int p, int vie) {
        super(nom, caractere, force, dexterite, constitution, intelligence, vitesse, arme, tete, haut, bas, pieds, a, p, vie);
        this.nbSuperPouvoir = 4;
    }

    public void setNbSuperPouvoir(int nbSuperPouvoir) {
        this.nbSuperPouvoir = nbSuperPouvoir;
    }

    public int getNbSuperPouvoir() {
        return nbSuperPouvoir;
    }

    @Override
    public void superPouvoir() {
        if (this.nbSuperPouvoir > 0) {
            System.out.println("Vous vous soignez.");
            this.setVie(this.getVie() * 5/4);
            this.nbSuperPouvoir -= 1;
        } else {
            System.out.println("Vous n'avez plus de super pouvoir.");
        }
    }
}
