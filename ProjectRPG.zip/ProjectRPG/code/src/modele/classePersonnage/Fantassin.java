package modele.classePersonnage;

import modele.Objets;

public class Fantassin extends Distance {

    public Fantassin(String nom, String caractere, double force, double dexterite, double constitution, double intelligence, double vitesse, Objets arme, Objets tete, Objets haut, Objets bas, Objets pieds, String a, int p, int vie) {
        super(nom, caractere, force, dexterite, constitution, intelligence, vitesse, arme, tete, haut, bas, pieds, a, p, vie);
    }
}
