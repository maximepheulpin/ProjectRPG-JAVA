package modele.salle.concrete;

import modele.*;
import modele.salle.factory.SalleFactory;
import modele.entite.Ennemi;
import modele.entite.Entite;
import modele.entite.Joueur;
import modele.prototype.PrototypeSalle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.math.BigDecimal;

public abstract class SalleGlobale {

    Joueur j1;
    public Affichable[][] carte;
    private int hauteur, largeur;
    protected int position_joueur_x;
    protected int position_joueur_y;
    public boolean premier_spawn = true;
    public static final String ANSI_RED = "\u001B[31m";

    public Map<String, Objets> objets_sur_map; //XY, Objets
    public Map<String, Ennemi> ennemis_sur_map; //XY, Ennemis
    public boolean entree = false;
    protected String debut = "E";
    protected String caractere = " ";
    private SalleFactory salleFactory;
    private int indice_salle = 0;




    public SalleGlobale(Joueur j, SalleFactory sF){
        hauteur = 5;
        largeur = 11;
        carte = new Affichable[hauteur][largeur];
        salleFactory = sF;
        j1 = j;
        objets_sur_map = new HashMap<>();
        ennemis_sur_map = new HashMap<>();
    }

    public void ajoutObjets() { //Modification de val de retour
        int[] x = {0, 1, 2, 3, 4};
        int[] y = {1, 3, 7, 9};
        int cpt = 0;
        ArrayList<Objets> objets = salleFactory.ajoutObjets();
        ArrayList<String> position_existante = new ArrayList<>();
        for (String s : ennemis_sur_map.keySet()){
            position_existante.add(s);
        }
        while(cpt < objets.size()) {
            int indicex = (int) (Math.random() * 5);
            int indicey = (int) (Math.random() * 4);
            String position = "" + x[indicex] + "" + y[indicey];
            if (!position_existante.contains(position)) {
                position_existante.add(position);
                Objets objTmp = objets.get(cpt);
                objTmp.setValeur(objTmp.getValeur()+indice_salle*2.5);
                objets_sur_map.put(position,objets.get(cpt));
                carte[x[indicex]][y[indicey]] = objets.get(cpt);
                cpt++;
            }
        }
    }

    public void ajoutEnnemis() { //Modification de val de retour
        int[] x = {0, 1, 2, 3, 4};
        int[] y = {1, 3, 7, 9};
        int cpt = 0;
        ArrayList<Ennemi> ennemis = salleFactory.ajoutEnnemis();
        ArrayList<String> position_existante = new ArrayList<>();
        while(cpt < ennemis.size()) {
            int indicex = (int) (Math.random() * 5);
            int indicey = (int) (Math.random() * 4);
            String position = "" + x[indicex] + "" + y[indicey];
            if (!position_existante.contains(position)) {
                position_existante.add(position);
                Ennemi tmp = ennemis.get(cpt);
                tmp.setDegat(tmp.getDegat()+indice_salle*1.5);
                tmp.setVie(tmp.getVie()+indice_salle*1.6);
                ennemis_sur_map.put(position,tmp);
                carte[x[indicex]][y[indicey]] = ennemis.get(cpt);
                cpt++;
            }
        }
    }

    public void ajoutBoss(){
        int[] x = {0, 1, 2, 3, 4};
        int[] y = {1, 3, 7, 9};
        int cpt = 0;
        Ennemi e = salleFactory.ajoutBoss();
        int indicex = (int) (Math.random() * 5);
        int indicey = (int) (Math.random() * 4);
        String position = "" + x[indicex] + "" + y[indicey];
        ennemis_sur_map.put(position,e);
        carte[x[indicex]][y[indicey]] = e;
    }



    public void creerSalleGlobale(){
        for (int i = 0; i < hauteur; i++) {
            for (int j = 0; j < largeur; j++) {
                if (j == largeur-1 || j%2 == 0) {
                    carte[i][j] = new Afficher("  |  ");
                }
                else{
                    carte[i][j] = new Afficher(caractere);
                }
            }
        }
        carte[hauteur-1][5] = j1;
        position_joueur_x = hauteur-1;
        position_joueur_y = 5;
        carte[0][5] = new Afficher("S");
    }

    public void remplacerJoueur(Joueur j1) {
        carte[hauteur-1][5] = j1;
        carte[0][5] = new Afficher("S");
    }

    public PrototypeSalle creerPrototypeSalle() { //Création d'une sauvegarde (à appeler avant chaque combat)
        return new PrototypeSalle(j1, carte, hauteur, largeur, position_joueur_x, position_joueur_y, premier_spawn, objets_sur_map, ennemis_sur_map, entree, debut, caractere);
    }

    public void restaurerPrototypeSalle(PrototypeSalle memento) {
        this.j1 = memento.getJ1();
        this.carte = memento.getCarte();
        this.hauteur = memento.getHauteur();
        this.largeur = memento.getLargeur();
        this.position_joueur_x = memento.getPosition_joueur_x();
        this.position_joueur_y = memento.getPosition_joueur_y();
        this.premier_spawn = memento.isPremier_spawn();
        this.objets_sur_map = memento.getObjets_sur_map();
        this.ennemis_sur_map = memento.getEnnemis_sur_map();
        this.entree = memento.isEntree();
        this.debut = memento.getDebut();
        this.caractere = memento.getCaractere();
    }


    public void deplacement(int type, int pallier){
        if (pallier == 0){
            debut = caractere;
        }
        else{
            debut = "E";
        }
        if (type == 0){
            carte[position_joueur_x][position_joueur_y] = new Afficher(caractere);
            carte[hauteur-1][5] = new Afficher(debut);
            carte[0][5] = new Afficher("S");
            carte[position_joueur_x][position_joueur_y+2] = j1;
            position_joueur_y += 2;
        }
        else if (type == 1){
            carte[position_joueur_x][position_joueur_y] = new Afficher(caractere);
            carte[hauteur-1][5] = new Afficher(debut);
            carte[0][5] = new Afficher("S");
            carte[position_joueur_x][position_joueur_y-2] = j1;
            position_joueur_y -= 2;
        }
        else if (type == 2){
            carte[position_joueur_x][position_joueur_y] = new Afficher(caractere);
            carte[hauteur-1][5] = new Afficher(debut);
            carte[0][5] = new Afficher("S");
            carte[position_joueur_x-1][position_joueur_y] = j1;
            position_joueur_x -= 1;
        }
        else if (type == 3){
            carte[position_joueur_x][position_joueur_y] = new Afficher(caractere);
            carte[hauteur-1][5] = new Afficher(debut);
            carte[0][5] = new Afficher("S");
            carte[position_joueur_x+1][position_joueur_y] = j1;
            position_joueur_x += 1;
        }
    }

    public boolean verif_deplacement(int t, int indice){
        if ((position_joueur_y == 1 && t == 1 ) || (position_joueur_y == largeur-2 && t == 0) ||
                (position_joueur_x == 0 && t == 2) || (position_joueur_x == hauteur-1 && t == 3)){
            return false;
        }

        if(position_joueur_x == hauteur-2 && position_joueur_y == 5 && premier_spawn ||
                position_joueur_x == hauteur-1 && position_joueur_y == 3 && premier_spawn ||
                position_joueur_x == hauteur-1 && position_joueur_y == 7 && premier_spawn){
            return false;
        }

        return true;
    }


    public boolean sur_objet(){
        String pos = ""+position_joueur_x+""+position_joueur_y;
        int indice = -1;
        for (String p : objets_sur_map.keySet()){
            if(p.equals(pos)) {
                Objets trouve = objets_sur_map.get(p);
                if (trouve.getType().equals("Coffre")){
                    System.out.println("Vous avez gagnez " + trouve.getValeur() + " pieces !");
                    j1.setPieces((int) trouve.getValeur());
                    objets_sur_map.remove(p);
                    return true;
                }
                if (j1.getTaille_inventaire() == 3) {
                    String tmp = choix_inventaire(trouve);
                    if (tmp.equals("N")){
                        return true;
                    }
                    else if(tmp.equals("O")){
                        indice = remplacement_inventaire(j1);
                    }
                }
                    switch (trouve.getType()) {
                        case "Potion":
                            System.out.println("Vous avez obtenu une potion !");
                            j1.setInventaire(trouve,indice);
                            objets_sur_map.remove(p);
                            return true;
                        case "Arme":
                            System.out.println("Vous avez obtenu une arme !");
                            j1.setInventaire(trouve,indice);
                            objets_sur_map.remove(p);
                            return true;
                    }
            }
        }
        return false;
    }

    public boolean sur_ennemis(){
        String pos = ""+position_joueur_x+""+position_joueur_y;
        for(String p : ennemis_sur_map.keySet()){
            if(p.equals(pos)){
                Entite trouve = ennemis_sur_map.get(p);
                if(trouve.getCaractere().equals("M") || trouve.getCaractere().equals("B")){
                    System.out.println(ANSI_RED+"Vous etes tombé sur un "+ trouve.getNom() + "\n");
                    return true;
                }
            }
        }
        return false;
    }

    public abstract void affichageSalle();
    public boolean sortie(){
        return (position_joueur_x == 0 && position_joueur_y == 5);
    }

    public boolean entree(){
        return (position_joueur_x == hauteur-1 && position_joueur_y == 5);
    }

    public abstract String getCouleur();

    public boolean isPremier_spawn() {
        return premier_spawn;
    }


    public Map<String, Ennemi> getEnnemisSurMap() {
        return ennemis_sur_map;
    }

    public int getHauteur() {
        return hauteur;
    }

    public int getLargeur() {
        return largeur;
    }

    public int getPositionX() {
        return position_joueur_x;
    }

    public void setCarte(Affichable[][] carte) {
        this.carte = carte;
    }

    public Affichable[][] getCarte() {
        return carte;
    }

    public int getPositionY() {
        return position_joueur_y;
    }

    public void setPosition_joueurMort_x() {
        this.position_joueur_x = hauteur-1;
    }

    public String choix_inventaire(Objets o){
        System.out.println("Vous avez atteint la limite de votre inventaire");
        while(true){
            System.out.println("Pour rappel l'objet trouvé etait :"+"\n");
            System.out.println(o);
            System.out.println("C'est l'unique occasion que vous aurez de le recupérer, souhaitez vous le prendre ?  (N) / (O)");
            String choix = new Scanner(System.in).next().toUpperCase();
            if (choix.equals("N")){
                return "N";
            }
            else if(choix.equals("O")){
                return "O";
            }
        }
    }
    public int remplacement_inventaire(Joueur j){
        while(true){
            j.afficherInventaire();
            System.out.println("De quel objet souhaitez vous vous débarassez ?");
            Scanner sc = new Scanner(System.in);
            if (sc.hasNextInt()) {
                int choix = sc.nextInt();
                if (choix > 0 && choix <= j.getInventaire().size()){
                    return choix;
                }
            }
        }
    }

    public void setPosition_joueurMort_y() {
        this.position_joueur_y = 5;
    }

    public void setPremier_spawn(boolean premier_spawn) {
        this.premier_spawn = premier_spawn;
    }

    public boolean aucunEnnemi() {
        return ennemis_sur_map.isEmpty();
    }


    public int getIndice_salle() {
        return indice_salle;
    }

    public void setIndice_salle(int indice_salle) {
        this.indice_salle = indice_salle;
    }
}