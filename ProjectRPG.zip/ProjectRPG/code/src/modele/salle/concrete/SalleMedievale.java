package modele.salle.concrete;

import modele.Affichable;
import modele.entite.Ennemi;
import modele.entite.Joueur;
import modele.Objets;
import modele.salle.concrete.SalleGlobale;
import modele.salle.factory.SalleFactory;

import java.util.HashMap;
import java.util.Map;

public class SalleMedievale extends SalleGlobale {
    private String couleur;
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_WHITE = "\u001B[37m";

    public SalleMedievale(Joueur j, SalleFactory salleFactory){
        super(j,salleFactory);
        couleur = "\u001B[32m";
    }

    @Override
    public void affichageSalle() {
        String ligne = couleur + "______________" +
                "_____________________";
        System.out.println("\n");
        for (int i = 0; i < getHauteur(); i++) {
            System.out.println(ligne);
            for (int j = 0; j < getLargeur(); j++) {
                switch (getCarte()[i][j].getCaractere()){
                    case "M":
                        System.out.print(ANSI_RED+getCarte()[i][j].getCaractere());
                        break;
                    case "C":
                        System.out.print(ANSI_YELLOW+getCarte()[i][j].getCaractere());
                        break;
                    case "P":
                        System.out.print(ANSI_PURPLE+getCarte()[i][j].getCaractere());
                        break;
                    case "A":
                        System.out.print(ANSI_CYAN+getCarte()[i][j].getCaractere());
                        break;
                    default:
                        System.out.print(couleur+getCarte()[i][j].getCaractere());
                        break;
                }
            }
            System.out.println();
        }
        System.out.println(ligne + "\n");
    }

    @Override
    public String getCouleur() {
        return couleur;
    }
}
