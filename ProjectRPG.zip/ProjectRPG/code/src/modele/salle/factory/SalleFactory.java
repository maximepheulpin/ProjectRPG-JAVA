package modele.salle.factory;

import modele.Items;
import modele.Objets;
import modele.entite.Ennemi;
import modele.entite.Joueur;
import modele.salle.concrete.SalleGlobale;

import java.util.ArrayList;

public interface SalleFactory {
    public SalleGlobale creerSalle(Joueur j);
    public ArrayList<Objets> ajoutObjets();
    public ArrayList<Ennemi> ajoutEnnemis();
    public ArrayList<Items> shop();
    public Ennemi ajoutBoss(); //TODO AJOUT
}
