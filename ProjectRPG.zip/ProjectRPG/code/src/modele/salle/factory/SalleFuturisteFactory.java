package modele.salle.factory;
import modele.Items;
import modele.Objets;
import modele.entite.Ennemi;
import modele.entite.Joueur;
import modele.salle.concrete.SalleFuturiste;
import modele.salle.concrete.SalleGlobale;
import modele.salle.concrete.SalleMedievale;

import java.util.ArrayList;

public class SalleFuturisteFactory implements SalleFactory {

    @Override
    public SalleFuturiste creerSalle(Joueur j) {
        return new SalleFuturiste(j,new SalleFuturisteFactory());
    }
    @Override
    public ArrayList<Objets> ajoutObjets(){
        ArrayList<Objets> objets = new ArrayList<>();
        ArrayList<Objets> armes = new ArrayList<>();
        ArrayList<Objets> consommables = new ArrayList<>();

        armes.add(new Objets("Arme","Sabre laser nucléaire",5,"A"));
        armes.add(new Objets("Arme","Cristaux de Zirkonium",3,"A"));
        armes.add(new Objets("Arme","Lance Antimatière",7,"A"));

        consommables.add(new Objets("Potion","Liquide de Refroidissement",4,"P"));
        consommables.add(new Objets("Potion","Cristal de vitalité",2,"P"));
        consommables.add(new Objets("Potion","Seringue de Plantitanium",5,"P"));

        int indexArmeAleatoire = (int) (Math.random() * armes.size());
        int indexConsommablesAleatoire = (int) (Math.random() * consommables.size());

        Objets ArmeAleatoire = armes.get(indexArmeAleatoire);
        Objets ConsommablesAleatoire = consommables.get(indexConsommablesAleatoire);
        objets.add(ArmeAleatoire);
        objets.add(ConsommablesAleatoire);
        objets.add(new Objets("Coffre","Coffre pixélisé",25,"C"));
        return objets;
    }

    @Override
    public ArrayList<Ennemi> ajoutEnnemis() {
        ArrayList<Ennemi> ennemis = new ArrayList<>();
        ArrayList<Ennemi> tmp = new ArrayList<>();
        tmp.add(new Ennemi("Parasites Technologiques","M",3.0,5.0,2.0,7.0,4.0,"Repand un nuage de pixel",8.0,7.0));
        tmp.add(new Ennemi("Entité Extra_dimensionnelle","M",7.0,7.0,4.0,5.0, 4.0,"Utilise des portails pour vous atteindre",14.0,4.0));
        tmp.add(new Ennemi("Cyberpunk","M",4.0,2.0,7.0,3.0, 8.0,"Use de techniques quantique pour vous affaiblir",10.0,5.0));

        for(int i = 0; i< tmp.size(); i++) {
            int indexAleatoire = (int) (Math.random() * tmp.size());
            ennemis.add(tmp.get(indexAleatoire));
            tmp.remove(tmp.get(indexAleatoire));
        }
        return ennemis;
    }

    @Override
    public ArrayList<Items> shop() { //Utilisation d'un ArrayList pour faciliter l'ajout de plusieurs objets sur le magasin
        ArrayList<Items> items = new ArrayList<>();
        items.add(new Items("Token","Token de Super Pouvoir",1,"T",75));
        return items;
    }

    @Override
    public Ennemi ajoutBoss() {
        return new Ennemi("Ultime créateur de Chaos","B",7.0,5.0,2.0,7.0,4.0,"Détruit l'espace temps",18,10.0);
    }
}
