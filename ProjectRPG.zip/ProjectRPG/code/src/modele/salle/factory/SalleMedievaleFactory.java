package modele.salle.factory;

import modele.Items;
import modele.Objets;
import modele.entite.Ennemi;
import modele.entite.Joueur;
import modele.salle.concrete.SalleGlobale;
import modele.salle.concrete.SalleMedievale;

import java.util.ArrayList;

public class SalleMedievaleFactory implements SalleFactory {

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";


    @Override
    public SalleMedievale creerSalle(Joueur j) {
        return new SalleMedievale(j,new SalleMedievaleFactory());
    }
    @Override
    public ArrayList<Objets> ajoutObjets(){
        ArrayList<Objets> objets = new ArrayList<>();
        ArrayList<Objets> armes = new ArrayList<>();
        ArrayList<Objets> consommables = new ArrayList<>();

        armes.add(new Objets("Arme","Epee tranchante",5,"A"));
        armes.add(new Objets("Arme","Lance pierre",3,"A"));
        armes.add(new Objets("Arme","Gant de maillage resistant",4,"A"));

        consommables.add(new Objets("Potion","Gourde du brave",10,"P"));
        consommables.add(new Objets("Potion","Bouquet d'herbes soignante",3,"P"));
        consommables.add(new Objets("Potion","Ragout de légumes anciens",6,"P"));

        int indexArmeAleatoire = (int) (Math.random() * armes.size());
        int indexConsommablesAleatoire = (int) (Math.random() * consommables.size());

        Objets ArmeAleatoire = armes.get(indexArmeAleatoire);
        Objets ConsommablesAleatoire = consommables.get(indexConsommablesAleatoire);
        objets.add(ArmeAleatoire);
        objets.add(ConsommablesAleatoire);
        objets.add(new Objets("Coffre","Coffre rare",25,"C"));
        return objets;

    }

    @Override
    public ArrayList<Ennemi> ajoutEnnemis() {
        ArrayList<Ennemi> ennemis = new ArrayList<>();
        ArrayList<Ennemi> tmp = new ArrayList<>();
        tmp.add(new Ennemi("Esprit","M",5.0,3.0,4.0,8.0,4.0,"balaye le vent ténébreux",20,4));
        tmp.add(new Ennemi("Revenant","M",3.0,6.0,1.0,7.0,4.0,"utilise vos morts pour vous atteindre",17,2));
        tmp.add(new Ennemi("Cavalier","M",7.0,6.0,5.0,3.0,4.0,"brandit la lance et vous atteint",21,3));

        for(int i = 0; i< tmp.size(); i++) {
            int indexAleatoire = (int) (Math.random() * tmp.size());
            ennemis.add(tmp.get(indexAleatoire));
            tmp.remove(tmp.get(indexAleatoire));
        }
        return ennemis;
    }

    @Override
    public ArrayList<Items> shop() { //Utilisation d'un ArrayList pour faciliter l'ajout de plusieurs objets sur le magasin
        ArrayList<Items> items = new ArrayList<>();
        items.add(new Items("Token","Token de Super Pouvoir",1,"T",75));

        return items;
    }

    @Override
    public Ennemi ajoutBoss() {
        return new Ennemi("Petit Prince","B",7.0,3.0,4.0,8.0,4.0,"Déploie ses multiples talents",20,8);
    }
}
