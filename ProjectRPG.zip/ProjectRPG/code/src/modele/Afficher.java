package modele;

public class Afficher implements Affichable{

    String caractere;
    public Afficher(String c) {
        this.caractere = c;
    }
    public String getCaractere() {
        return caractere;
    }
}
