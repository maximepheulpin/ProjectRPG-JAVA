package vue;

import modele.Items;
import modele.Objets;
import modele.entite.Joueur;

import java.util.ArrayList;
import java.util.Scanner;

public class Ihm {

    //private final String theme;
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String ANSI_RESET = "\u001B[0m";

    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_PURPLE = "\u001B[35m";

    public Ihm() {
    }

    public String choix_theme(){
        while(true){
            System.out.println("Veuillez choisir le theme du jeu (medieval / futuriste)");
            String choix = new Scanner(System.in).next().toUpperCase();
            if(choix.equals("MEDIEVAL") || choix.equals("M")){
                System.out.println("Le theme choisi est : "+choix);
                return "M";
            }
            else if(choix.equals("FUTURISTE") || choix.equals("F")){
                System.out.println("Le theme choisi est : "+choix);
                return "F";
            }
        }
    }

    public String classe_joueur(String theme){
        if (theme.equals("M")){
            while(true){
                System.out.println("Veuillez choisir la classe de votre personnage (mage / chevalier / fantassin)");
                Scanner sc = new Scanner(System.in);
                String choix = sc.next().toUpperCase();
                if(choix.equals("CHEVALIER") || choix.equals("C")){
                    System.out.println("la classe choisie est : CHEVALIER");
                    return "CHEVALIER";
                }
                else if(choix.equals("MAGE") || choix.equals("M")){
                    System.out.println("la classe choisie est : MAGE");
                    return "MAGE";
                }
                else if(choix.equals("FANTASSIN") || choix.equals("F")){
                    System.out.println("la classe choisie est : FANTASSIN");
                    return "FANTASSIN";
                }
            }
        }
        else if(theme.equals("F")){
            while(true){
                System.out.println("Veuillez choisir la classe de votre personnage (cyborg / hacker / spectre)");
                String choix = new Scanner(System.in).next().toUpperCase();
                if(choix.equals("CYBORG") || choix.equals("C")){
                    System.out.println("la classe choisie est : CYBORG");
                    return "CYBORG";
                }
                else if(choix.equals("HACKER") || choix.equals("H")){
                    System.out.println("la classe choisie est : HACKER");
                    return "HACKER";
                }
                else if(choix.equals("SPECTRE") || choix.equals("S")){
                    System.out.println("la classe choisie est : SPECTRE");
                    return "SPECTRE";
                }
            }
        }
        return null;
    }




    public int choix_taille_donjon(){
        while(true){
            System.out.println("Souhaitez vous une aventure Rapide, Modérée ou Longue ?  (R) / (M) / (L)");
            String choix = new Scanner(System.in).next().toUpperCase();
            if(choix.equals("R")){
                return 5;
            }
            else if(choix.equals("M")){
                return 8;
            }
            else if(choix.equals("L")){
                return 11;
            }
            else{
                System.out.println("Veuillez saisir une entrée valide.");
            }
        }
    }

    public String choix_nom(){
        System.out.println("Choisir nom personnage");
        String choix = new Scanner(System.in).next();
        System.out.println("Bonne aventure : "+choix);
        return choix;
    }


    public void num_salle(int indice){
        System.out.println(ANSI_WHITE+"************* Salle "+indice+" *************");
    }

    public String choix_fin_partie(){
        while(true){
            System.out.println("Souhaitez vous revenir dans le passé ou sortir du donjon?  (R) / (S)");
            String choix = new Scanner(System.in).next().toUpperCase();
            if(choix.equals("R")){
                return "R";
            }
            else if(choix.equals("S")){
                return "S";
            }
        }
    }

    public void condamner(){
        System.out.println("Vous avez assez remonté dans le temps pour aujourd'hui."+"\n"+"c'est reparti pour un tour !");
    }

    public String getMenuJoueur(Joueur j) {
        System.out.println("Afficher équipement de départ (E) ou Rentrer dans le donjon (D)");
        String choix = new Scanner(System.in).next().toUpperCase();
        if (choix.equals("E") || choix.equals("D")) {
            if ("E".equals(choix)) {
                j.afficherEquipement();
                pause(5);
            }
            System.out.println("Vous entrez dans le donjon");
            System.out.println();
            return "D"; //Si on affiche inventaire on entre dans le donjon
        }
        return "";
    }

    public String actionPersonnage(){
        System.out.println("\u001B[40m"+ANSI_WHITE+"Attaquer (A) / Super Pouvoir (S) / Essayer d'esquiver (E) / Ouvrir l'inventaire (O)" + ANSI_RESET);
        while (true) {
            String action = new Scanner(System.in).next().toUpperCase();
            switch (action) {
                case "A" :
                    return "Attaquer";
                case "S" :
                    return "Pouvoir";
                case "O" :
                    return "Consommer";
                case "E" :
                    return "Esquiver";
            }
        }
    }

    public void debut_partie(){
        System.out.println("Pour Rappel les collectibles sont représentés par des : "+ANSI_PURPLE+"P"+ANSI_RESET+"\n"
                +"les armes sont représentés par des : "+ANSI_CYAN+"A"+ANSI_RESET+"\n"+
                "les ennemis sont représentés par des : "+ANSI_RED+"M"+ANSI_RESET+"\n"+
                "et les coffres sont représentés par des : "+ANSI_YELLOW+"C"+ANSI_RESET+"\n");
        System.out.println("De plus, le menu Pause permet d'accéder au magasin, consulter votre inventaire ou accéder à votre équipement." + "\n");
    }
    public void pause(int tmpSec) {
        try {
            Thread.sleep(tmpSec*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int deplacement(){
        while(true){
            System.out.println("Deplacez vous ! (D) / (Q) / (Z) / (S) ");
            System.out.println("Ou souhaitez faire Pause ? (P)");
            String choix = new Scanner(System.in).next().toUpperCase();
            if(choix.equals("D")){
                return 0;
            }
            else if(choix.equals("Q")){
                return 1;
            }
            else if(choix.equals("Z")){
                return 2;
            }
            else if(choix.equals("S")){
                return 3;
            }
            else if(choix.equals("P")){
                return -1;
            }
            else{
                System.out.println("action non disponible");
            }
        }
    }

    public int afficher_interne(Joueur j){
        while(true) {
            System.out.println("Souhaitez vous afficher votre equipement / votre inventaire ou quitter le menu Pause? (E) / (I) / (Q)");
            String choix = new Scanner(System.in).next().toUpperCase();
            if(choix.equals("E")){
                j.afficherEquipement();
                return -2;
            }
            else if(choix.equals("I")){
                if (j.getInventaire().isEmpty()){
                    j.afficherInventaire();
                    return -2;
                }
                else{
                    return choixInventaire(j);
                }
            }
            else if (choix.equals("Q")) {
                return -3;
            }
        }
    }

    public int afficher_externe(Joueur j){
        while(true) {
            System.out.println("Souhaitez vous accéder au magasin / afficher votre equipement / votre inventaire ou quitter le menu Pause? (M) / (E) / (I) / (Q)");
            String choix = new Scanner(System.in).next().toUpperCase();
            if(choix.equals("E")){
                j.afficherEquipement();
                return -2;
            }
            else if(choix.equals("I")){
                if (j.getInventaire().isEmpty()){
                    j.afficherInventaire();
                    return -2;
                }
                else{
                    return choixInventaire(j);
                }
            }
            else if (choix.equals("Q")) {
                return -3;
            }
            else if (choix.equals("M")){
                return 4;
            }
        }
    }

    public int choixInventaire(Joueur j){
        while(true) {
            j.afficherInventaire();
            System.out.println("Choisissez l'objet que vous souhaitez utiliser ? Saisir 0 pour quitter");
            try {
                int choix = new Scanner(System.in).nextInt();
                if (choix > 0 && choix <= j.getInventaire().size()){
                    return choix-1;
                }
                else if (choix == 0){
                    System.out.println("Vous quittez votre inventaire !\n");
                    return -1;
                }
                System.out.println("L'objet souhaitez n'existe pas !\n");
            } catch (Exception e) {
                System.out.println(e);
            }

        }
    }

    public int choixMagasin(Joueur j, ArrayList<Items> t){
        int cpt = 1;
        String header = "╔══════════════════════ MAGASIN ══════════════════════╗";
        int longueurTotale = header.length();
        System.out.println(header);
        if (t.isEmpty()){
            afficherLigneCentree("Aucun objet dans le magasin actuellement...", longueurTotale);
            System.out.println("╚═════════════════════════════════════════════════════╝");
            return -1;
        }
        for(Objets o : t){
            afficherLigneCentree(cpt+" : "+o, longueurTotale);
            cpt++;
        }
        System.out.println("╚═════════════════════════════════════════════════════╝");
        System.out.println("Pour rappel, vous possédez "+j.getPieces()+" pieces."+"\n");
        while(true) {
            System.out.println("Choisissez l'objet que vous souhaitez acheter? Saisir 0 pour quitter le magasin");
            try {
                int choix = new Scanner(System.in).nextInt();
                if (choix > 0 && choix <= t.size()){
                    if(t.get(choix-1).getPrix() <= j.getPieces()) {
                        return choix-1;
                    }
                    else {
                        System.out.println("Vous n'avez pas le montant nécéssaire pour cette objet !");
                    }
                }
                else if (choix == 0){
                    System.out.println("Vous quittez le magasin !\n");
                    return -1;
                }
                else {
                    System.out.println("L'objet souhaitez n'existe pas !\n");
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    public void afficherLigneCentree(String ligne, int longueurTotale) {
        int sideGauche = (longueurTotale - ligne.length()) / 2 - 1;
        int sideDroite = longueurTotale - ligne.length() - sideGauche - 2;
        //System.out.println(sideDroite + " " + sideGauche);
        String ligneCentree = "║";
        for (int i = 0; i < sideGauche; i++) {
            ligneCentree += " ";
        }
        ligneCentree += ligne;
        for (int i = 0; i < sideDroite; i++) {
            ligneCentree += " ";
        }
        ligneCentree += "║";
        System.out.println(ligneCentree);
    }
}
